while true; do pm2 restart main.js ; sleep 500; done
